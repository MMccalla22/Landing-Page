/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/
const navMenu = document.getElementById("navbar__list");
const listSections = document.querySelectorAll("section");
const navListSections = [...document.querySelectorAll("section")];
const menuLinks = document.querySelectorAll(".navbar__menu a"); 
let navMenuItems = navListSections.length;
/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
const flexibleNavBar = () => {
    for (navListSection of navListSections) {
        navListSectionName = navListSection.getAttribute("data-nav");
        navListSectionLink = navListSection.getAttribute("id");
        navMenuListItem = document.createElement("li");
        navMenuListItem.innerHTML = `<a class='menu__link' href='#${navListSectionLink}'>${navListSectionName}</a>`;
        navMenu.appendChild(navMenuListItem);
    }
};

// Add class 'active' to section when near top of viewport

const sectionViewport = (view) => {
    let sectionxy = view.getBoundingClientRect();
    return sectionxy.top <= 150 && sectionxy.bottom >= 150;
};//section is near top of viewport

const addActiveClass = () => {
    // function to add active class to viewed section
    for (navListSection of navListSections) {
        if (sectionViewport(navListSection)) {
            if (!navListSection.classList.contains("your-active-class")) {
                navListSection.classList.add("your-active-class");
            }
        } else {
            navListSection.classList.remove("your-active-class");
        }
    }
};
// Scroll to anchor ID using scrollTO event
const easyScroll = () => {
    document.querySelectorAll(".menu__link").forEach((anchor) => {
        // selects all anchors with class='menu__link'
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            document.querySelector(anchor.getAttribute("href")).scrollIntoView({
                behavior: "smooth",
            });
        });
    });
};

/**
 * End Main Functions
 * Begin Events
 * 
*/

//To the top button
let toTopButton = document.getElementById("to-top");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    toTopButton.style.display = "block";
  } else {
    toTopButton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

// Build menu 
flexibleNavBar();
// Scroll to section on clicking link
easyScroll();
// Set sections as active
document.addEventListener("scroll", addActiveClass);

