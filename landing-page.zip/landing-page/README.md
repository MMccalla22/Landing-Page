

# Landing Page - UDACITY Nanodegree Program

This project is for Udacity's Front End Nanodegree program. HTML and CSS starter code provided by [Udacity](https://www.udacity.com/).

##Description

This is a basic landing page that uses Javascript to create a NavBar dynamically and to highlight sections when scrolled. 

The aim of this project is to build a multi-section landing page, with a dynamically updating navigational menu based on the amount of content that is added to the page. 

The starter code (static, non-interactive version of the project) is available here](https://github.com/udacity/fend/tree/refresh-2019). 

Detailed project instructions [here](https://review.udacity.com/#!/rubrics/2658/view)


## Languages used

HTML
CSS
JAVASCRIPT


# Footer

Clone Project [here](https://github.com/MMccalla22/Land-Page.git)